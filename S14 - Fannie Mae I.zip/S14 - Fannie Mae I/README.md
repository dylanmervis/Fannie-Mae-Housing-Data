Topic:  Data Wrangling

Case:   Connecticut Avenue Securities - Sharing Data (UVA-QA-0903)

Data:   Available from Fannie Mae, MSA_name_pop_data.csv

Code:   FannieMaeDataPreprocessingStarter.ipynb

We will study this case over two classes. Your preparation this class will be understanding how the dataset is constructed and the outlines of what we will be doing in the class project. For the second day, your team will use the full data set to build a predictive model using a large virtual machine instance. Our ultimate goal for the second class will be to predict and visualize loan losses in default. For our first class, we will prepare and explore the data.

1. Read the case.
2. The data that you need for this assignment is already on JupyterHub. It is in the folder "Shared Data (Read Only)/Fannie Mae Preprocessing Data/". The relevant file is "2008Q2.csv". This data set on the performance of single family loans from the second quarter of 2008 was originally downloaded from [Fannie Mae's website](https://capitalmarkets.fanniemae.com/credit-risk-transfer/single-family-credit-risk-transfer/fannie-mae-single-family-loan-performance-data).
3. Familiarize yourself with the column headings of the data file 2008Q2.csv. To do so, look at the File Layout, Glossary, and FAQ. In the Glossary, pay special attention to the Zero Balance Code column in the Performance file. Which codes are severe credit events (i.e., events that are considered defaults)? Note that not all data fields are actually relevant for the data set we are working with. Fannie Mae has a single unified data glossary for several different mortgage related data sets that they release. The data fields that are present in our data set are the ones with a check mark in the "Single Family (SF) Loan Performance" column. The specific documents are linked below:
    * [Fannie Mae data glossary and file layout](https://capitalmarkets.fanniemae.com/media/6931/display)
    * [Fannie Mae data FAQ](https://capitalmarkets.fanniemae.com/media/8921/display)
4.	Go through FannieDataPreprocessingStarter.ipynb. This will compute the net loss for each loan in the data set by summarizing the performance data for each loan. Additionally, it removes all features that we wouldn't have at loan acquisition time. This gives us a data set we can use to build predictive models at loan acquisition time. Even for computing this small portion of the data, the virtual machines you have been using will be insufficient. You will need to select a virtual machine with at least 36 GB of memory. Please make sure you shut down these larger machines as soon as you finish by logging out. Otherwise, they will be particularly expensive for us to provide. Note that running this code will take a significant amount of time. Please plan accordingly.
5.	Come prepared to discuss what the final data set contains and how it is constructed from the original data set.
6.	Once you have constructed the 2008 quarter two portion of the final data set, you do not need to compute the rest of the data. We provide a pre-computed data set of loans from 2000 through 2021. This data can be found in "Shared Folder (Read Only)/Fannie Mae Data". This will be used for the second class session as well as your final project.